<?php 

class Producto extends AppModel {
    function search($keyword){
		$keyword = trim($keyword);
		$keyword = str_replace(" ","%",$keyword);
		// $this->Picture->query("SELECT * FROM productos where tags like '%".$keyword."%' order by ventas desc;");
		$res = $this->query("SELECT * FROM productos where tags like '%".$keyword."%' or titulo like '%".$keyword."%' order by vendidos desc;");
		return($res);
	}	
	
	function auditBusqueda($keyword,$lstRespuesta){
		foreach ($lstRespuesta as &$valor) {
			$titulo = $valor['productos']['titulo'];
			$res = $this->query("INSERT INTO busqueda values ('".$keyword."','".$titulo."')");
		}
	}
	
	function getAudit(){
		$res = $this->query("SELECT titulo, termino, COUNT(*) as contador FROM busqueda group by titulo order by contador desc limit 20");
		return($res);
	}
	
}