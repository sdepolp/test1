<?php
class BuscadorController extends AppController {
    
	public function Index(){
		
	}
	public function format2Query($keyword){
		$keyword = str_replace(" ","%",$keyword);
		return($keyword);
	}
	
	public function Search($keyword = null){
		$salida = "";
		$this->autoRender = false;
		// $keyword = "obra teatro";
		
		if($keyword != ""){
			$form_keyword = $this->format2Query($keyword);
			$this->loadModel('Producto');
			
			$salida = $this->Producto->search($form_keyword);
			
			
			//INSERTAR TERMINO BUSCADO EN TABLA BUSQUEDA
			$this->Producto->auditBusqueda($keyword,$salida);
			
		}
		return json_encode($salida);
		
		
		
	}
	
	public function stats(){
	}
	
	public function getStats(){
		$this->autoRender = false;
		$this->loadModel('Producto');
		$res = $this->Producto->getAudit();
		return json_encode($res);
	}
	
}
